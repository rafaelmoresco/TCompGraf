from controlador import Controlador

# Main
def main():
    controlador = Controlador()
    controlador.run()

if __name__ == "__main__":
    main()