## Para Executar
Para executar o trabalho, executar o comando
```sh
python3 main.py
```