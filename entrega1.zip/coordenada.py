from dataclasses import dataclass

@dataclass()
class Coordenada2D:
    x: float
    y: float
